def arithmetic_arranger(problems,solve=False):
  listedMaths = []
  length = len(problems)
  runs = 0
  result = ""
  difference = 0
  #checks length of list to make sure <= 5 problems
  if length > 5:
    return "Error: Too many problems."
  #Checks every item in the list for incorrect operands
  for problem in problems:
    if "/" in problem:
      return "Error: Operator must be '+' or '-'."
    #included x because it is often used for multiplication
    if "*" in problem or "x" in problem:
      return "Error: Operator must be '+' or '-'."
  #first for loop takes each problem and splits it at the white spaces
  #second for loop takes results of first for loop and asigns them to a list
  for math in problems:
    maths = math.split(" ")
    for subMath in maths:
      listedMaths.append(subMath)

  #try and except is used to try to cast every number to an int if it fails error is     thrown
  try:
    for ints in listedMaths:
      if ints != "+" and ints != "-":
        test = int(ints)
  
  except:
    return "Error: Numbers must only contain digits."

  #every item in listedMaths is tested for length
  for i in listedMaths:
    if len(i) > 4:
      return "Error: Numbers cannot be more than four digits."
      
  #each line is added individually to results
  while runs< length:
    difference = len(listedMaths[2+runs*3]) - len(listedMaths[runs*3])
    result +="  "
    while difference > 0:
      result +=" "
      difference -=1
    result +=listedMaths[runs*3]
    if runs+1 != length:
      result +="    "
    runs+=1
  result +="\n"
  runs = 0

  #second line
  while runs< length:
    #the difference in lengths of the top and bottom number is determined
    difference = len(listedMaths[runs*3]) - len(listedMaths[2+runs*3])
    result +=listedMaths[1+runs*3]+" "
    #for every top number that is smaller than the bottom spaces are added until they match
    while difference > 0:
      result += " "
      difference -=1
    result += listedMaths[2+runs*3]
    #makes sure spaces arnt added on the last run because test program was getting unhappy
    if runs+1 != length:
      result +="    "
    runs+=1

  result +="\n"
  runs = 0

  #third line
  while runs< length:
    result+="--"
    #determines how many dashes to add based on the largest number in stack
    if len(listedMaths[runs*3]) - len(listedMaths[2+runs*3]) > 0:
      difference = len(listedMaths[runs*3])
    else:
      difference = len(listedMaths[2+runs*3])
    # first difference can be used later in the code so just created this tosave the value for        while loop
    difference2 = difference
    while difference2>0:
      result +="-"
      difference2-=1
    if runs+1 !=length:
      #makes sure spaces arnt added on the last run
      result+="    "
    runs+=1

  #checks if the solve portion is enabled, default is False
  if solve == True:
    result+="\n"
    runs = 0

    while runs<length:
      #determines what operation to perform based on the operand
      if listedMaths[1+runs*3] == "+":
        solution = int(listedMaths[runs*3]) + int(listedMaths[2+runs*3])
      if listedMaths[1+runs*3] == "-":
        solution = int(listedMaths[runs*3]) - int(listedMaths[2+runs*3])

      #determines how many spaces will be needed based on the larger number in the stack
      if len(listedMaths[runs*3]) - len(listedMaths[2+runs*3]) > 0:
        difference = abs(len(listedMaths[runs*3])-len(str(solution)))
      else:
        difference = abs(len(listedMaths[2+runs*3])-len(str(solution)))

      #adds spaces
      while difference > 0:
        result+=" "
        difference-=1

      #if the solution is long enough no extra spaces are needed to compensate for operand
      if len(str(solution))<4:
        result+="  "
      result += str(solution)
      #makes sure spaces arnt added on the last run
      if runs+1 != length:
        result+="    "
      runs+=1
  return result
